extends Node2D

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$AnimatedSprite2D.play("default")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:

	if Input.is_action_just_pressed("ui_right"):
		$AnimatedSprite2D.play("girl_dcha")
		$AnimatedSprite2D.position.x += 15
	if Input.is_action_just_pressed("ui_left"):
		$AnimatedSprite2D.play("girl_izda")
		$AnimatedSprite2D.position.x -= 15
	
	# if Input.is_action_just_pressed("ui_up"):
	# 	$AnimatedSprite2D.play("move_up")
	# if Input.is_action_just_pressed("ui_down"):
	# 	$AnimatedSprite2D.play("move_down")
	# if Input.is_action_just_released("soltar_tecla"):
	# 	$AnimatedSprite2D.play("default")

	
