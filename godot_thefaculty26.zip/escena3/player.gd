extends CharacterBody2D


@export var speed = 200 


func get_input():
	var input_direction = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	velocity = input_direction*speed
	

func _physics_process(delta: float) -> void:
	# Add the gravity.
	get_input()
	# move_and_slide()
	
	# PARA DETECTAR COLISIONES usamos move_and_collide.
	var colision = move_and_collide(velocity * delta)
	
	# POSICION 
	if position.x > 1200:
		position.x = 1110


	# COLISIONES
	if colision:
		print("He chocado con..", colision.get_collider().name)
	
	# ELIMINAR 
	# 	if (colision.get_collider().name== "flowey"):
	#		get_parent().get_node("flowey").queue_free()
	
	# Salir de escena
	#
	#	if (colision.get_collider().name== "salida"):
	#		get_tree().change_scene_to_file("res://escena_1.tscn")
